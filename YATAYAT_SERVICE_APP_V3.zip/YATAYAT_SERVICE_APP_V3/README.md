# YATAYAT SERVICE APP V3

Mobile-friendly PWA starter with customer login/OTP demo, VIP membership gate, admin control center, editable services/documents, contact/WhatsApp/email settings, theme, QR setting, applications and status tracking.

Admin demo: developer2 / RAHUL7726044335
Demo OTP: 123456

IMPORTANT: This browser demo stores data in localStorage. Do not use it for real Aadhaar/DL/RC or other sensitive documents. Production requires a secure HTTPS backend, server-side auth/roles, private encrypted storage, real OTP and a compliant payment gateway. Verify current government/RTO requirements with the applicable official authority.

Run: serve this folder with a web server (for example `python -m http.server 8080`) and open it in Chrome/Safari. It can be added to the phone home screen.
